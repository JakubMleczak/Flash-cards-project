<?php
  require_once("skrypty/check.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Fisznet</title>
    <link rel="stylesheet" href="style2.css">

</head>

<body>
  <section>
  </section>
    <div id="wyloguj" class="icon">
      <a href="skrypty/logout.php"><img src="img/log.png" alt="wyloguj"></a>

    </div>

   <main id="zestawy">
     <!--
dodawanie div przez php
     -->

     <div>
       <a href="uzytkownik.php"> <p>użytkownicy</p></a>

     </div>
     <div>
      <a href="dodawanie.php"> <p>dodawanie zestawu</p></a>
     </div>


   </main>

</body>
</html>

<!-- -wyswietlanie fiszek
-wyloguj
- dodawanie zestawu(nauczyciel)
-edytowanie zestawu(nauczyciel)
-dodawanie i usuwanie userow
-->
