<?php

if(isset($_POST['username'])&&isset($_POST['password']))
{
  require_once('conn.php');
  $username=$_POST['username'];
  $pass=$_POST['password'];

  $username=strip_tags(mysqli_real_escape_string($conn,trim($username)));
  $pass=strip_tags(mysqli_real_escape_string($conn,trim($pass)));

  $query = "SELECT * FROM `uzytkownicy` WHERE `login`='$username' AND `ID_statusu`=1";
  $wynik= mysqli_query($conn,$query);
  if(mysqli_num_rows($wynik)>0)
  {
    $row = mysqli_fetch_array($wynik);
    $password= $row['haslo'];
    $nauczyciel= $row['nauczyciel'];
    $status= $row['ID_statusu'];

      $szyfr= $pass;

      if(password_verify($szyfr,$password))
      {
        session_start();

        $_SESSION['login']=$login;
        $_SESSION['nauczyciel']=$nauczyciel;
        $_SESSION['status']=$status;
        $_SESSION['id']=session_id();

        if($nauczyciel==0)
        {
          header("location: ../jezyk.php");
        }
        else
        {
          header("location: ../admin.php");
        }


      }else
        {
           header("location: ../index.php");
        }
    }
    else {
     header("location: ../index.php");
    }
}
else {
 header("location: ../index.php");
}
 ?>
