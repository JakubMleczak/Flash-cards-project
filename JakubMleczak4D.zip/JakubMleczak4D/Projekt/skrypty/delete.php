<?php

if(isset($_GET['id']))
{
  require_once("conn.php");
  $id = $_GET['id'];
echo $id;
  $sql2="UPDATE `uzytkownicy` SET `ID_statusu`='2' WHERE `login`='$id'";
  if($id!="admin")
  {


  $wynik2 = mysqli_query($conn,$sql2);
  if(mysqli_query($conn,$sql2)){
    echo 'ok';
  }else
  echo "blad";
}
header("location: ../edycja.php");
}



 ?>
