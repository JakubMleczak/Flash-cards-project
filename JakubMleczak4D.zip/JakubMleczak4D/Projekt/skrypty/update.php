<?php
if(isset($_POST['przycisk'])){
   $imie =$_POST['imie'];
   $surname =$_POST['surname'];
$id = $_POST['id'];
   $nauczyciel = $_POST['nauczyciel'];
   $id_klasy = $_POST['klasa'];



echo "<br>";
   echo $imie;echo "<br>";
   echo $surname;echo "<br>";
echo $id;

   require_once('conn.php');


    $sql22="UPDATE `uzytkownicy` SET `login`='$id',`imie`='$imie',`nazwisko`='$surname',`nauczyciel`='$nauczyciel',`id_klasa`='$id_klasy', `ID_statusu`='1' WHERE  `login`='$id'";
   if(mysqli_query($conn,$sql22)){
     echo 'ok';
    header('location: ../');
   }else{
     echo 'err';
   }
 }
 else
 echo "blad";

 ?>
