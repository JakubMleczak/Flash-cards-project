<?php

if(isset($_POST['submit'])&& !empty($_POST['nazwazestawu']))
{
  $nazwa3=$_POST['nazwazestawu'];
$jezyk3 = $_POST['jezykopt'];
$tekst=$_POST['jezyk3'];
$tlumaczenie=$_POST['jezyk2'];
  var_dump($tekst);
  var_dump($tlumaczenie);
require_once("conn.php");
echo $tekst[3];
echo $tlumaczenie[2];
echo "<br>";
$sqltest = "Select id_zestawu from zestawy where nazwa = '$nazwa3' AND id_jezyk='$jezyk3'";
$ile = mysqli_query($conn, $sqltest);
if(mysqli_affected_rows($conn)==0)
{
  $sql2 = "INSERT INTO `zestawy`(`id_zestawu`, `id_jezyk`, `nazwa`) VALUES (NULL,'$jezyk3','$nazwa3')";
  mysqli_query($conn,$sql2);
}

$sprawdzenie = "Select id_zestawu from zestawy where nazwa = '$nazwa3'  AND id_jezyk='$jezyk3' ";
$check  = mysqli_query($conn,$sprawdzenie);
$idzestaw = mysqli_fetch_assoc($check);
$id =  $idzestaw['id_zestawu'];
  for ($i=0; $i <count($tekst) ; $i++) {
    if(!empty($tekst[$i]) && !empty($tlumaczenie[$i]) )
    {


      $sql = "INSERT INTO `fiszki`(`id_fiszki`, `id_zestawu`, `tekst`, `tlumaczenie`) VALUES (NULL,'$id','$tekst[$i]','$tlumaczenie[$i]')";
      echo mysqli_error($conn);
      echo "<br>";
      if(mysqli_query($conn,$sql))
      {
      }else echo "err";
    }
  }
  header("location: ../admin.php");
 }

      else
      {
        echo "nie dziala 3 ";
       header("location: ../admin.php");
      }

 ?>
