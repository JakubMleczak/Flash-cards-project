<?php

if(isset($_POST['submit'])&& !empty($_POST['login'])
&& !empty($_POST['haslo'])
&& !empty($_POST['imie'])&&!empty($_POST['nazwisko']))
{
  $login=$_POST['login'];
  echo $login;

  $userpass = $_POST['haslo'];
$rola= $_POST['nauczyciel'];

  echo $rola;
  $imie=$_POST['imie'];
  $nazwisko=$_POST['nazwisko'];
  $status=1;
  $szyfr_password=password_hash($userpass,PASSWORD_ARGON2ID);

        require_once("conn.php");

    $sql = "SELECT * FROM `uzytkownicy` WHERE `login`=\"$login\"";
    $wynik =  mysqli_query($conn,$sql);
    while($row = mysqli_fetch_assoc($wynik)){
echo "<br>";
      echo $row['login'];
      echo "<br>";
    }

         if(mysqli_num_rows($wynik)==0)
         {
           if(!empty($_POST['klasa']))
           {
             $class=$_POST['klasa'];
             $sqlwstawianie = "INSERT INTO `uzytkownicy`
             (`login`, `haslo`, `imie`, `nazwisko`, `nauczyciel`, `id_klasa`, `ID_statusu`)
             VALUES ('$login', '$szyfr_password', '$imie', '$nazwisko','$rola', '$class','$status')";
           }
           else
           {
             $sqlwstawianie = "INSERT INTO `uzytkownicy`
             (`login`, `haslo`, `imie`, `nazwisko`, `nauczyciel`, `ID_statusu`)
             VALUES ('$login', '$szyfr_password', '$imie', '$nazwisko','$rola' ,'$status')";
           }


          if(mysqli_query($conn,$sqlwstawianie)){

                     header("location: ../uzytkownik.php");
                       }
                       else{
                         echo "nie dziala 1 ";
                        header("location: ../nowy.php");
                       };
            }
            else
                {
                     echo "nie dziala 2 ";
            header("location: ../nowy.php");
                 }
      }
      else
      {
        echo "nie dziala 3 ";
  header("location: ../nowy.php");
      }

 ?>
